"use strict";
const fs = require("node:fs");
const path = require("node:path");
const test = require("node:test");
const assert = require("node:assert/strict");
const read = file => fs.readFileSync(path.join(__dirname, "..", file), "utf8");

test("A Google token renews earlier during active use", () => {
  const drive = read("app.js");
  assert.match(drive, /DRIVE_GESTURE_RENEW_WINDOW_MS = 25 \* 60 \* 1000/);
  assert.match(drive, /remaining > DRIVE_GESTURE_RENEW_WINDOW_MS/);
  assert.match(drive, /await this\.requestToken\(false\)/);
  assert.match(drive, /if \(silent\) \{\s*return Promise\.reject/);
  assert.match(drive, /loadCachedDriveToken\(\)/);
});

test("Ordinary app clicks never open the Google login popup", () => {
  const boot = read("app.js");
  assert.doesNotMatch(boot, /DriveDB\.renewFromUserGesture\(\)/);
});

test("App shell updates together and preserves cached signed-in browser state", () => {
  assert.match(read("index.html"), /app\.js\?v=769/);
  assert.match(read("index.html"), /sw\.js\?v=769/);
  assert.match(read("sw.js"), /branchline-pwa-v769/);
  assert.doesNotMatch(read("app.js"), /localStorage\.clear\(\)/);
});
